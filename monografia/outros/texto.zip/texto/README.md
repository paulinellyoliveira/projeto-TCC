A documentação sobre a classe está disponível na monografia exemplo (**monografia.pdf**) e os comentários no arquivo **monografia.tex**.
